# 1N600002_1N6000B_3X_PARSED_COORDS

## Purpose

Focused `1N6000B` parsed-coordinate beautifier probe.
This case goes through `generate_component_placement_project`; it is not a helper-only binary edit.

## Input

```json
{
  "components": {
    "1N6000B": 3
  },
  "layout": {
    "binary_coordinate_mutation": true,
    "strategy": "beautify"
  },
  "schema": "component-placement/v0.1"
}
```

## Output

- Project: `1N600002_1N6000B_3X_PARSED_COORDS.pdsprj`
- Manifest: `1N600002_1N6000B_3X_PARSED_COORDS.pdsprj.manifest.json`

## What To Check In Proteus

3 `1N6000B` components should move onto the beautifier grid. Check for DLL errors, bad object records, and detached labels/values.

## User Result

Pending.

## Codex Observation

Pending user Proteus result.
