BIDIR_V3_T06_RCL21_RULE_BASELINE

Open this generated mixed R/C/L project in Proteus 8.13.

Project: BIDIR_V3_T06_RCL21_RULE_BASELINE.pdsprj
Groups: 9 (RCL, RC, LC, RCL, RL, RC, RCL, LC, RL)
Components: 21 (7R, 7C, 7L)
Static validation issues: []

Locked endpoint rules:
- V0/power uses the accepted donor-derived $TERPOWER -> $TEROUTPUT bridge.
- Component starts use $TERINPUT terminals.
- Component ends use $TEROUTPUT, except G0 endpoints use $TERGROUND.
- R/C/L, RC, LC, RL, C-only, R-only, and L-only blocks are made by removing whole subgroups from accepted donor units.
