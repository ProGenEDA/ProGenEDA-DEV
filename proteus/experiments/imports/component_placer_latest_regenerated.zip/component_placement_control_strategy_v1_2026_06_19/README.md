# Component Placement Control Strategy V1

These projects were generated through the integrated generator:

```powershell
python -m proteusgen.cli generate-component-placement <input.json> --output <output.pdsprj>
```

No standalone generation script was used for this pack.

## Test Order

1. `CP01_SWITCH_PRECEDENCE_SWITCH_ONLY`
2. `CP02_HIDDEN_DUMMY_SWITCH_ONLY`
3. `CP03_SWITCH_PRECEDENCE_POT_PAIR`
4. `CP04_HIDDEN_DUMMY_POT_PAIR`
5. `CP05_SWITCH_PRECEDENCE_STRESS`
6. `CP06_HIDDEN_DUMMY_STRESS`
7. `CP07_DISPLAY_4027_D20_BRIDGE`

## Control Strategies

- `switch_precedence`: skips early SWITCH packets using `switch_offset: 21`.
- `hidden_dummy_switch`: keeps a dummy first SWITCH far off-sheet, then uses later SWITCH packets visibly.

## Current Component Names

Digital/display:

`7SEG-COM-AN-BLUE`, `7SEG-COM-CAT-BLUE`, `4027`, `4511`, `7447`, `7490`, `74HC00`, `74HC02`, `74HC04`, `74HC08`, `74HC32`, `74HC74`, `74HC76`, `74HC85`, `74HC86`, `74HC151`, `74HC157`, `74HC160`, `74HC174`, `74HC192`, `74HC266`, `74HC283`.

Basic/analog/source:

`RESISTOR`, `CAP`, `CAP-ELEC`, `REALIND`, `DIODE`, `1N4007`, `1N4148`, `1N4733A`, `1N6000B`, `IRDIODE`, `LED-RED`, `BRIDGE`, `FUSE`, `NPN`, `PNP`, `2N3904`, `2N4401`, `NMOSFET`, `2N7000`, `BS170`, `LM317T`, `LM741`, `OPAMP`, `NE555`, `POT-HG`, `SWITCH`, `VSOURCE`, `CSOURCE`, `VPULSE`.

`VSINE` is available in the donor set, but should only be requested when explicitly needed.

## Integrated Pre-New-Component Rules

- Display requests such as `7segcomanode` and `7segcomk` normalize to the raw donor markers `7SEG-COM-AN-BLUE` and `7SEG-COM-CAT-BLUE`.
- 7-segment output uses the accepted D20-bridged display rule from the main mega donor.
- New-control families such as `SWITCH`, `POT-HG`, `FUSE`, `BRIDGE`, `VPULSE`, `2N7000`, and `BS170` use the new-component mega donor and the component-specific selectors in `src/proteusgen/component_placer.py`.
