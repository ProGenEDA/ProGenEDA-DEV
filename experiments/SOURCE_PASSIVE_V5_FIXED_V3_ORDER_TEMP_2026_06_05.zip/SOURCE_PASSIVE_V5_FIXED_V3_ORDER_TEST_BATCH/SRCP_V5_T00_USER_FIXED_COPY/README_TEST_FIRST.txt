Open and simulate SRCP_V5_T00_USER_FIXED_COPY.pdsprj
