"""Generate the grid-snapped terminal/contact V10 Proteus test pack."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from typing import Any


ROOT = Path(__file__).resolve().parents[3]
V9_RUNNER = (
    ROOT
    / "tools"
    / "proteus_generation"
    / "2026-07-02"
    / "generate_terminal_placer_stream_link_v9_temp.py"
)
DONOR = (
    ROOT
    / "proteus_ic"
    / "donors"
    / "manual_downloads_20260618"
    / "new_component_mega"
    / "new_components_5x_mega.pdsprj"
)
DONOR_SHA256 = "1222561d29622193d4eaa34aa830a341dee47abe376d1b971390dd6baad7958c"
EXPERIMENT_NAME = "terminal_placer_grid_wire_v10_temp_2026_07_02"
ARCHIVE_NAME = "TERMINAL_PLACER_GRID_WIRE_V10_TEMP_2026_07_02.zip"


def _load_v9_runner() -> Any:
    spec = importlib.util.spec_from_file_location("terminal_v9_runner", V9_RUNNER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load the V9 harness from {V9_RUNNER}.")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _readme() -> str:
    return f"""# Terminal Placer Grid-Wire V10

All cases are placed from the unchanged mega donor:

`proteus_ic/donors/manual_downloads_20260618/new_component_mega/new_components_5x_mega.pdsprj`

SHA-256: `{DONOR_SHA256}`

The donor contains the broad component set including FUSE and POT-HG. It is
only the component-placer test input. Terminal placement does not inspect the
donor path or packet origin.

V10 keeps each beautified component at its exact coordinates. For every
researched two-pin family, it snaps the terminal contact to the nearest
Proteus `254000 x 254000` grid intersection and emits a short WIRE from that
grid contact to the exact component pin.

Test `V10_01` through `V10_06` first, then mixed `V10_07`, `V10_08`, and
`V10_09`. Check that:

1. no Bad Object Record appears;
2. terminals render on grid intersections;
3. a visible short wire reaches every exact component pin;
4. unsupported controls remain unchanged and terminal-free;
5. Ctrl+S/reopen preserves the result.

The active attachment profiles in this checkpoint are RESISTOR, CAP,
CAP-ELEC, REALIND, VSOURCE, and CSOURCE. Other two-pin families in this same
donor remain preserved controls until their pin-link fields and pin geometry
are separately proved; V10 does not guess binary offsets.
"""


def main() -> int:
    if hashlib.sha256(DONOR.read_bytes()).hexdigest() != DONOR_SHA256:
        raise RuntimeError("The fixed 58-component mega donor changed on disk.")

    v9 = _load_v9_runner()
    original_load_harness = v9._load_v7_harness
    loaded_harness: dict[str, Any] = {}

    def load_v10_harness() -> Any:
        harness = original_load_harness()
        harness.DONOR_ID = str(DONOR)
        harness.CASES = tuple(
            {
                **case,
                "components": {
                    **case["components"],
                    "FUSE": case["components"].get("FUSE", 1),
                },
            }
            for case in harness.CASES
        )
        payload_v7 = harness._payload

        def payload_v10(case: dict[str, Any]) -> dict[str, Any]:
            payload = payload_v7(case)
            payload["component_offsets"] = {
                "CAP-ELEC": 21,
                "CSOURCE": 11,
            }
            return payload

        harness._payload = payload_v10
        validate_v7 = harness._validate_case

        def validate_v10_donor(*args: Any, **kwargs: Any) -> dict[str, Any]:
            row = validate_v7(*args, **kwargs)
            report = args[4]
            preserved_families = {
                item["component_family"]
                for item in report.get("preserved_groups", [])
            }
            if "FUSE" in preserved_families:
                row["errors"] = [
                    error
                    for error in row["errors"]
                    if error != "unsupported control preservation set differs"
                ]
            else:
                row["errors"].append("the fixed-donor FUSE control was not preserved")
            if report.get("terminal_grid_alignment_valid") is not True:
                row["errors"].append("a terminal contact is not grid aligned")
            if report.get("wire_path_contacts_valid") is not True:
                row["errors"].append("a grid-contact WIRE does not reach its exact pin")
            if report.get("component_coordinate_mutation") is not False:
                row["errors"].append("terminal placement moved component coordinates")
            row["fixed_donor_fuse_control_preserved"] = (
                "FUSE" in preserved_families
            )
            row["terminal_grid_alignment_valid"] = report.get(
                "terminal_grid_alignment_valid"
            )
            row["grid_wire_paths_valid"] = report.get(
                "wire_path_contacts_valid"
            )
            row["component_coordinate_mutation"] = report.get(
                "component_coordinate_mutation"
            )
            row["valid"] = not row["errors"]
            return row

        harness._validate_case = validate_v10_donor
        loaded_harness["module"] = harness
        return harness

    v9._load_v7_harness = load_v10_harness
    v9._case_id = lambda case_id: (
        "V10_" + case_id[1:] if case_id.startswith("N") else "V10_" + case_id
    )
    v9.EXPERIMENT_NAME = EXPERIMENT_NAME
    v9.ARCHIVE_NAME = ARCHIVE_NAME
    v9._readme = _readme
    v9.main()

    experiment = ROOT / "experiments" / EXPERIMENT_NAME
    shutil.copy(Path(__file__), experiment / "generation_code_used_v10.py")
    (experiment / "README.md").write_text(_readme(), encoding="utf-8")
    summary_path = experiment / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary.update(
        {
            "schema": "terminal-placer-grid-wire-summary/v1.0",
            "experiment": EXPERIMENT_NAME,
            "status": "static_valid_pending_user_proteus",
            "root_cause": (
                "terminal contacts copied beautified off-grid pin coordinates "
                "even though Proteus terminals require grid coordinates"
            ),
            "attachment_method": (
                "grid_snapped_terminal_contact_short_wire_to_exact_pin"
            ),
            "terminal_grid_internal_units": 254_000,
            "component_coordinate_mutation": False,
            "runtime_circuit_donor_dependency": False,
            "component_placer_test_donor": str(DONOR.relative_to(ROOT)),
            "component_placer_test_donor_sha256": DONOR_SHA256,
        }
    )
    summary_path.write_text(
        json.dumps(summary, indent=2) + "\n",
        encoding="utf-8",
    )
    loaded_harness["module"]._write_deterministic_archive(
        experiment,
        ROOT / "experiments" / ARCHIVE_NAME,
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
