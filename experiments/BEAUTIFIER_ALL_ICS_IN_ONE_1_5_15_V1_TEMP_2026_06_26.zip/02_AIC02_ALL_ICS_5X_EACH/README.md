# AIC02_ALL_ICS_5X_EACH

## Purpose

All supported IC families in one bare component-placement project, `5` of each.
This stresses mixed IC footprints after the solo family tests.

## What To Check In Proteus

- There should be `5` package groups for every listed IC family.
- Multi-subpart gates such as 74HC00/02/04/08/32/86/266 must not overlap.
- Larger native ICs should be separated into readable rows.
- No terminals or wires are expected.
- Report crash, DLL error, bad object record, detached text, wrong count, or obvious overlap.

## User Result

Pending.
