Downloaded KiCad source files needed for generator analysis. See MANIFEST/download_results.csv.
