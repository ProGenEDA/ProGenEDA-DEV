#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WHEEL="$(find "$HERE/rust-wheels" -maxdepth 1 -type f -name 'progen_routing_core-*.whl' | head -n 1 || true)"
if [[ -z "$WHEEL" ]]; then
  echo 'No progen_routing_core wheel found in rust-wheels/.' >&2
  exit 1
fi
mkdir -p "$HERE/rust-site"
"${PYTHON:-python3}" -m pip install --upgrade --target "$HERE/rust-site" "$WHEEL"
"${PYTHON:-python3}" - <<'PY'
import importlib.util
raise SystemExit(0 if importlib.util.find_spec('progen_routing_core') else 1)
PY
