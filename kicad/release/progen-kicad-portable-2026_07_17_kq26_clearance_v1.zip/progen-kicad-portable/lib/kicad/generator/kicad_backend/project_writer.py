from __future__ import annotations

import json
from .sexpr import ROOT_UUID


def write_kicad_pro(project_name: str) -> str:
    """Write the narrow .kicad_pro JSON subset used by KiCad's PROJECT_FILE path."""
    return json.dumps(
        {
            "meta": {"filename": f"{project_name}.kicad_pro", "version": 1},
            "sheets": [[ROOT_UUID, ""]],
            "libraries": {"pinned_symbol_libs": [], "pinned_footprint_libs": []},
            "text_variables": {},
            "boards": [],
            "board": {"design_settings": {"defaults": {}, "rules": {}}},
            "schematic": {
                "drawing": {"default_line_thickness": 6, "default_text_size": 50},
                "meta": {"version": 1},
                "plot_directory": "",
            },
            "erc": {"erc_exclusions": [], "meta": {"version": 0}},
            "net_settings": {
                "classes": [
                    {
                        "name": "Default",
                        "clearance": 0.2,
                        "track_width": 0.25,
                        "via_diameter": 0.8,
                        "via_drill": 0.4,
                        "wire_width": 6,
                    }
                ],
                "meta": {"version": 3},
            },
        },
        indent=2,
    ) + "\n"
