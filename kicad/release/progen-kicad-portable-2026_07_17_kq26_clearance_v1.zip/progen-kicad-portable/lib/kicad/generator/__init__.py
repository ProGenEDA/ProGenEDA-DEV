"""KiCad CircuitIR generation helpers."""
