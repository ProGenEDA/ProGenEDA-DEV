# ProGenEDA KiCad Portable Executable

Built: 2026_07_10

Run:

```bash
./progen-kicad run path/to/main.json --output-root /tmp/progen-kicad-out --routing-mode combination
```

The executable is a portable folder, not a zipapp, because the KiCad
pipeline intentionally reads bundled KiCad source/catalogue files by
filesystem path.

Rust routing core:

- The Python pipeline works without the Rust extension and falls back
  to the verified Python router.
- To enable the bundled CPython wheel on a compatible Linux/Python
  host, run `./install-rust-core.sh` once inside this folder.
- The launcher automatically adds `rust-site/` to `PYTHONPATH`.

Website contract:

- Input: canonical ProGenEDA main JSON or a folder of main JSON files.
- Default mode: `combination`.
- User artifact: `PROGEN_KICAD_PROJECT.zip`.
- Internal artifact: `internal_bundle.zip` containing every JSON,
  validation report, retained route/placement variants, and the
  generated project export under `export/KC/`.
